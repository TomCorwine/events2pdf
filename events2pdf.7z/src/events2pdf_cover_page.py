
def make_cover_page():      
    mcover_page = f"""
<b><font size="+3">
Alcoholics Anonymous<br/>
District 14<br/>
Meeting Schedule
</font></b><br/><font size="+2">
A.A. Hotline 352-372-8091<br/>
North Central Florida Intergroup Inc.<br/>
Land Title Plaza<br/>
2832  NW 43 St. Bld. 1000   Suite 1182<br/>
Office  & A.A. Hotline  352-372-8091<br/>
Office Hours: Monday-Wednesday 2:00-5:00 pm<br/>
Thursday & Friday  2:00-6:00 pm<br/>
Saturday  11:00 am-2:00 pm<br/>
For the latest meeting list see: www.aagainesville.org</font><br/>
<b><font size="+3">
Meeting Legend</font></b><br/><font size="+2">
O&mdash;Open, anyone can attend; C&mdash;Closed,only<br/>
requirement is a desire to stop drinking;<br/>
D&mdash;Discussion; S&mdash;Speaker; M&mdash;Meditation;<br/>
BB&mdash;Big Book Study; SS/STS&mdash;Step Study/Steps &amp;
Traditions; Lit&mdash;Other AA Literature;<br/>
BG&mdash;Beginners; WC&mdash;Wheelchair Accessible;<br/>
NC&mdash;No Children; CCP&mdash;Child care provided.<br/><br/></font>
"""
    return(mcover_page)